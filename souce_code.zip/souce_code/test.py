from Image_pre_process import img_pre_prs
from DCT_Forward import DCT_All_image

path = './Test_data/Miko.jpeg'
blocks = img_pre_prs(path)
print(blocks[0])
blocks = DCT_All_image(blocks)
print('DCT complete')
print(blocks[0])
